import os
from openai import OpenAI
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def classify(query, history=None):
    try:
        prompt = f"""Return JSON with intent, agent, entities, safety. Query: {query}"""
        res = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role":"user","content":prompt}],
            temperature=0
        )
        return eval(res.choices[0].message.content)
    except:
        return {"intent":"unknown","agent":"stub","entities":{},"safety":"unknown"}
