import yfinance as yf

def get_return(t):
    stock=yf.Ticker(t)
    h=stock.history(period="1y")
    if h.empty: return 0
    return ((h["Close"][-1]-h["Close"][0])/h["Close"][0])*100

def portfolio_health_agent(portfolio):
    if not portfolio:
        return {"message":"Start investing with ETFs.","disclaimer":"Not advice"}
    returns=[get_return(p["ticker"]) for p in portfolio]
    avg=sum(returns)/len(returns)
    return {"performance":{"return_pct":avg},"disclaimer":"Not advice"}
