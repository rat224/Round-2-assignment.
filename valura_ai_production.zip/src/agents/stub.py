def stub_agent(p):
    return {"message":"Agent not implemented","disclaimer":"Not advice"}
