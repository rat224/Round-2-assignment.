memory_store = {}

def get_history(session_id):
    return memory_store.get(session_id, [])

def add_to_history(session_id, query):
    memory_store.setdefault(session_id, []).append(query)
