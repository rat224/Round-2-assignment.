from fastapi import FastAPI
from sse_starlette.sse import EventSourceResponse
from src.safety import safety_guard
from src.classifier import classify
from src.router import route_agent
from src.memory import get_history, add_to_history

app = FastAPI()

@app.post("/query")
async def query_endpoint(request: dict):

    def event_generator():
        session_id = request.get("session_id", "default")

        yield {"event": "status", "data": "Running safety check..."}
        safety = safety_guard(request["query"])
        if safety["blocked"]:
            yield {"event": "error", "data": safety["message"]}
            return

        history = get_history(session_id)

        yield {"event": "status", "data": "Classifying..."}
        classification = classify(request["query"], history)

        add_to_history(session_id, request["query"])

        yield {"event": "status", "data": f"Routing to {classification['agent']}"}

        agent = route_agent(classification)
        response = agent(request.get("portfolio", []))

        for k, v in response.items():
            yield {"event": "chunk", "data": f"{k}: {v}"}

    return EventSourceResponse(event_generator())
