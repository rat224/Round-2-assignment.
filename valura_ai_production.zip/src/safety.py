import re

patterns = {
    "insider_trading": r"insider|non-public",
    "guaranteed_returns": r"guaranteed profit|100% return",
    "manipulation": r"pump and dump",
}

def safety_guard(query):
    for category, pattern in patterns.items():
        if re.search(pattern, query.lower()):
            return {"blocked": True, "message": f"Blocked due to {category}"}
    return {"blocked": False}
