from src.agents.portfolio import portfolio_health_agent
from src.agents.stub import stub_agent

def route_agent(c):
    if c["agent"]=="portfolio_health":
        return portfolio_health_agent
    return stub_agent
