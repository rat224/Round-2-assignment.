# Valura AI Microservice (Production Version)

## Setup
pip install -r requirements.txt
uvicorn src.main:app --reload

## Features
- Safety Guard (regex-based)
- LLM Classifier (OpenAI)
- Portfolio Health Agent (yfinance)
- Session Memory
- SSE Streaming

## Env
Create .env:
OPENAI_API_KEY=your_key

## Run Tests
pytest tests/ -v

## Video Explanation (Script included separately)
