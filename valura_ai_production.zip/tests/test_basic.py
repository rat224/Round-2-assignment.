from src.safety import safety_guard

def test_block():
    assert safety_guard("insider trading")["blocked"]
